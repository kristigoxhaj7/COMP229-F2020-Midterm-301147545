/*
    File Name: db.js
    Student Name: Kristi Goxhaj
    StudentID: 301147545
    Date: 27/10/2022
*/

module.exports = {
  //local MongoDB deployment ->
  "URI": process.env.MONGODB_URI
};
